$(function(){
 $('#btnEnviar4').click(function(){
   const tabla=$('#tablas').val(); const nombre=$('#nombre4').val(); const fecha=$('#fecha').val(); const email=$('#email4').val(); const sexo=$('input[name="Sexo"]:checked').val()||'';
   $.post('procesaTABLA.php',{tabla:tabla},function(r){
     let h=`<h3>Consulta: ${esc($('#tablas option:selected').text())}</h3>`;
     if(nombre||fecha||email||sexo) h+=`<p><strong>Datos introducidos:</strong> ${esc(nombre)} ${esc(fecha)} ${esc(email)} ${esc(sexo)}</p>`;
     if(!r.completado){$('#res').html(h+`<div class="alert alert-warning">${esc(r.message)}</div>`);return;}
     if(!r.data.length){$('#res').html(h+'<p>No hay resultados.</p>');return;}
     const cols=Object.keys(r.data[0]); h+='<div class="table-responsive"><table id="tablaConsulta" class="table table-striped table-hover"><thead><tr>'+cols.map(c=>`<th>${esc(c)}</th>`).join('')+'</tr></thead><tbody>';
     r.data.forEach(row=>h+='<tr>'+cols.map(c=>`<td>${esc(row[c])}</td>`).join('')+'</tr>'); h+='</tbody></table></div>'; $('#res').html(h); $('#tablaConsulta').DataTable();
   },'json').fail(()=>$('#res').html('<div class="alert alert-danger">No se pudo contactar con procesaTABLA.php</div>'));
 });
 function esc(x){return $('<div>').text(x??'').html();}
});
