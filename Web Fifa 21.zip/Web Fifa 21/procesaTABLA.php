<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'conexion.php';
function outT($data=[], $message='Ok', $ok=true){echo json_encode(['data'=>$data,'message'=>$message,'completado'=>$ok],JSON_UNESCAPED_UNICODE);exit;}
$tabla=$_REQUEST['tabla']??'';
try{
 $db=estableceConexion();
 switch($tabla){
  case 'jugador': $q=$db->query('SELECT idJugador, Nombre, Media, Nacionalidad, Posicion, Club_Nombre FROM Jugador ORDER BY Media DESC, Nombre'); break;
  case 'estilo': $q=$db->query('SELECT Nombre, Estadísticas FROM `EstilosQuímica` ORDER BY Nombre'); break;
  case '5skill': $q=$db->query('SELECT idJugador, Nombre, Media, Club_Nombre, Skills FROM Jugador WHERE Skills=5 ORDER BY Media DESC, Nombre'); break;
  case 'linkverde': $q=$db->query("SELECT h.Jugador_idJugador AS Jugador1, j1.Nombre AS NombreJugador1, h.Jugador_idJugador1 AS Jugador2, j2.Nombre AS NombreJugador2, h.TipoLink FROM `HaceQuímica` h JOIN Jugador j1 ON j1.idJugador=h.Jugador_idJugador JOIN Jugador j2 ON j2.idJugador=h.Jugador_idJugador1 WHERE h.TipoLink='Verde' ORDER BY j1.Nombre, j2.Nombre"); break;
  case 'esta_nominada_a': outT([], 'La base de datos conservada no contiene una tabla o relación de nominaciones (esta_nominada_a), por lo que esta consulta no puede recuperarse fielmente.', false);
  default: outT([], 'Tabla no reconocida.', false);
 }
 outT($q->fetchAll(PDO::FETCH_ASSOC));
}catch(Throwable $e){outT([], 'No se pudo consultar la base de datos: '.$e->getMessage(), false);}
