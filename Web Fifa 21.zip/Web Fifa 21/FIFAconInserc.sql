-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema Fifa
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema Fifa
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `Fifa` DEFAULT CHARACTER SET utf8 ;
USE `Fifa` ;

-- -----------------------------------------------------
-- Table `Fifa`.`Estadio`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Fifa`.`Estadio` (
  `Nombre` VARCHAR(50) NOT NULL,
  `Capacidad` VARCHAR(45) NULL,
  PRIMARY KEY (`Nombre`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Fifa`.`Federación`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Fifa`.`Federación` (
  `Nombre` VARCHAR(50) NOT NULL,
  `País` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Nombre`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Fifa`.`Club`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Fifa`.`Club` (
  `Nombre` VARCHAR(50) NOT NULL,
  `Estadio_Nombre` VARCHAR(50) NOT NULL,
  `Federación_Nombre` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`Nombre`),
  INDEX `fk_Club_Estadio1_idx` (`Estadio_Nombre` ASC),
  INDEX `fk_Club_Federación1_idx` (`Federación_Nombre` ASC),
  CONSTRAINT `fk_Club_Estadio1`
    FOREIGN KEY (`Estadio_Nombre`)
    REFERENCES `Fifa`.`Estadio` (`Nombre`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Club_Federación1`
    FOREIGN KEY (`Federación_Nombre`)
    REFERENCES `Fifa`.`Federación` (`Nombre`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Fifa`.`Entrenador`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Fifa`.`Entrenador` (
  `Nombre` VARCHAR(50) NOT NULL,
  `Nacionalidad` VARCHAR(45) NOT NULL,
  `Club_Nombre` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`Nombre`),
  INDEX `fk_Entrenador_Club_idx` (`Club_Nombre` ASC),
  CONSTRAINT `fk_Entrenador_Club`
    FOREIGN KEY (`Club_Nombre`)
    REFERENCES `Fifa`.`Club` (`Nombre`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Fifa`.`EstilosQuímica`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Fifa`.`EstilosQuímica` (
  `Nombre` VARCHAR(50) NOT NULL,
  `Estadísticas` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`Nombre`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Fifa`.`Jugador`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Fifa`.`Jugador` (
  `idJugador` VARCHAR(50) NOT NULL,
  `Nombre` VARCHAR(45) NOT NULL,
  `Media` INT NOT NULL,
  `Nacionalidad` VARCHAR(45) NOT NULL,
  `Posicion` VARCHAR(45) NOT NULL,
  `Edad` INT NOT NULL,
  `Altura` INT NOT NULL,
  `PiernaBuena` VARCHAR(45) NOT NULL,
  `Ritmo` INT NOT NULL,
  `Regate` INT NOT NULL,
  `Tiro` INT NOT NULL,
  `Defensa` INT NOT NULL,
  `Pase` INT NOT NULL,
  `Fisico` INT NOT NULL,
  `Skills` INT NOT NULL,
  `PiernaMala` INT NOT NULL,
  `Entrenador_Nombre` VARCHAR(50) NOT NULL,
  `EstilosQuímica_Nombre` VARCHAR(50) NOT NULL,
  `Club_Nombre` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`idJugador`),
  INDEX `fk_Jugador_Entrenador1_idx` (`Entrenador_Nombre` ASC),
  INDEX `fk_Jugador_Estilos de química1_idx` (`EstilosQuímica_Nombre` ASC),
  INDEX `fk_Jugador_Club1_idx` (`Club_Nombre` ASC),
  CONSTRAINT `fk_Jugador_Entrenador1`
    FOREIGN KEY (`Entrenador_Nombre`)
    REFERENCES `Fifa`.`Entrenador` (`Nombre`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Jugador_Estilos de química1`
    FOREIGN KEY (`EstilosQuímica_Nombre`)
    REFERENCES `Fifa`.`EstilosQuímica` (`Nombre`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Jugador_Club1`
    FOREIGN KEY (`Club_Nombre`)
    REFERENCES `Fifa`.`Club` (`Nombre`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Fifa`.`Equipación`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Fifa`.`Equipación` (
  `Tipo` VARCHAR(50) NOT NULL,
  `Club_Nombre` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`Tipo`, `Club_Nombre`),
  INDEX `fk_Equipación_Club1_idx` (`Club_Nombre` ASC),
  CONSTRAINT `fk_Equipación_Club1`
    FOREIGN KEY (`Club_Nombre`)
    REFERENCES `Fifa`.`Club` (`Nombre`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Fifa`.`Torneo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Fifa`.`Torneo` (
  `Nombre` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`Nombre`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Fifa`.`Balón`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Fifa`.`Balón` (
  `Fase` VARCHAR(50) NOT NULL,
  `Torneo_Nombre` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`Fase`, `Torneo_Nombre`),
  INDEX `fk_Balón_Torneo1_idx` (`Torneo_Nombre` ASC),
  CONSTRAINT `fk_Balón_Torneo1`
    FOREIGN KEY (`Torneo_Nombre`)
    REFERENCES `Fifa`.`Torneo` (`Nombre`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Fifa`.`Participación`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Fifa`.`Participación` (
  `Torneo_Nombre` VARCHAR(50) NOT NULL,
  `Club_Nombre` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`Torneo_Nombre`, `Club_Nombre`),
  INDEX `fk_Torneo_has_Club_Club1_idx` (`Club_Nombre` ASC),
  INDEX `fk_Torneo_has_Club_Torneo1_idx` (`Torneo_Nombre` ASC),
  CONSTRAINT `fk_Torneo_has_Club_Torneo1`
    FOREIGN KEY (`Torneo_Nombre`)
    REFERENCES `Fifa`.`Torneo` (`Nombre`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Torneo_has_Club_Club1`
    FOREIGN KEY (`Club_Nombre`)
    REFERENCES `Fifa`.`Club` (`Nombre`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Fifa`.`HaceQuímica`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Fifa`.`HaceQuímica` (
  `Jugador_idJugador` VARCHAR(50) NOT NULL,
  `Jugador_idJugador1` VARCHAR(50) NOT NULL,
  `TipoLink` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`Jugador_idJugador`, `Jugador_idJugador1`),
  INDEX `fk_Jugador_has_Jugador_Jugador2_idx` (`Jugador_idJugador1` ASC),
  INDEX `fk_Jugador_has_Jugador_Jugador1_idx` (`Jugador_idJugador` ASC),
  CONSTRAINT `fk_Jugador_has_Jugador_Jugador1`
    FOREIGN KEY (`Jugador_idJugador`)
    REFERENCES `Fifa`.`Jugador` (`idJugador`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Jugador_has_Jugador_Jugador2`
    FOREIGN KEY (`Jugador_idJugador1`)
    REFERENCES `Fifa`.`Jugador` (`idJugador`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

insert into Estadio (Nombre, Capacidad) values 
('Allianz Arena',	75000),
('Anfield',	53000),
('Camp Nou',	99000),
('Emirates',	60000),
('Etihad',	55000),
('Juventus Stadium',	41500),
('Old Trafford',	76000),
('Parque de los Príncipes',	48000),
('San Paolo',	55000),
('San Siro',	80000),
('Santiago Bernabéu',	81000),
('Signal Iduna Park',	81000),
('Stamford Bridge',	42000),
('Tottenham Hotspur Stadium',	62000),
('Wanda Metropolitano',	68000),
('Wembley',	90000);

select * from Estadio;

insert into Federación (Nombre, País) values
('DFB',	'Alemania'),
('RFEF',	'España'),
('FFF',	'Francia'),
('FA',	'Inglaterra'),
('FIGC',	'Italia');

select * from Federación;

insert into Club (Nombre, Estadio_Nombre, Federación_Nombre) values
('AC Milán',	'San Siro',	'FIGC'),
('Arsenal',	'Emirates',	'FA'),
('Atlético de Madrid',	'Wanda Metropolitano',	'RFEF'),
('Barcelona',	'Camp Nou',	'RFEF'),
('Bayern Munich',	'Allianz Arena',	'DFB'),
('Borussia Dortmund',	'Signal Iduna Park',	'DFB'),
('Chelsea',	'Stamford Bridge',	'FA'),
('Inter de Milán',	'San Siro',	'FIGC'),
('Juventus',	'Juventus Stadium',	'FIGC'),
('Liverpool',	'Anfield',	'FA'),
('Manchester City',	'Etihad',	'FA'),
('Manchester United',	'Old Trafford',	'FA'),
('Napoli',	'San Paolo',	'FIGC'),
('PSG',	'Parque de los Príncipes',	'FFF'),
('Real Madrid',	'Santiago Bernabéu',	'RFEF'),
('Tottenham',	'Tottenham Hotspur Stadium',	'FA');

select * from Club;

insert into Entrenador (Nombre, Nacionalidad, Club_Nombre) values 
('Arteta',	'Española',	'Arsenal'),
('Conte',	'Italiana',	'Inter de Milán'),
('Flick',	'Alemana',	'Bayern Munich'),
('Gattuso',	'Italiana',	'Napoli'),
('Guardiola',	'Española',	'Manchester City'),
('Klopp',	'Alemana',	'Liverpool'),
('Koeman',	'Holandesa',	'Barcelona'),
('Mourinho',	'Portuguesa',	'Tottenham'),
('Pioli',	'Italiana',	'AC Milán'),
('Pirlo',	'Italiana',	'Juventus'),
('Pochettino',	'Argentina',	'PSG'),
('Simeone',	'Argentina',	'Atlético de Madrid'),
('Solskjaer',	'Noruega',	'Manchester United'),
('Terzic',	'Alemana',	'Borussia Dortmund'),
('Tuchel',	'Alemana',	'Chelsea'),
('Zidane',	'Francesa',	'Real Madrid');

select * from Entrenador;

insert into equipación (Tipo, Club_Nombre) values 
('1ª',	'AC Milán'),
('1ª',	'Arsenal'),
('1ª',	'Atlético de Madrid'),
('1ª',	'Barcelona'),
('1ª',	'Bayern Munich'),
('1ª',	'Borussia Dortmund'),
('1ª',	'Chelsea'),
('1ª',	'Inter de Milán'),
('1ª',	'Juventus'),
('1ª',	'Liverpool'),
('1ª',	'Manchester City'),
('1ª',	'Manchester United'),
('1ª',	'Napoli'),
('1ª',	'PSG'),
('1ª',	'Real Madrid'),
('1ª',	'Tottenham'),
('2ª',	'AC Milán'),
('2ª',	'Arsenal'),
('2ª',	'Atlético de Madrid'),
('2ª',	'Barcelona'),
('2ª',	'Bayern Munich'),
('2ª',	'Borussia Dortmund'),
('2ª',	'Chelsea'),
('2ª',	'Inter de Milán'),
('2ª',	'Juventus'),
('2ª',	'Liverpool'),
('2ª',	'Manchester City'),
('2ª',	'Manchester United'),
('2ª',	'Napoli'),
('2ª',	'PSG'),
('2ª',	'Real Madrid'),
('2ª',	'Tottenham'),
('3ª',	'Juventus'),
('3ª',	'Real Madrid'),
('Portero',	'AC Milán'),
('Portero', 'Arsenal'),
('Portero',	'Atlético de Madrid'),
('Portero',	'Barcelona'),
('Portero',	'Bayern Munich'),
('Portero',	'Borussia Dortmund'),
('Portero',	'Chelsea'),
('Portero',	'Inter de Milán'),
('Portero',	'Juventus'),
('Portero',	'Liverpool'),
('Portero',	'Manchester City'),
('Portero',	'Manchester United'),
('Portero',	'Napoli'),
('Portero',	'PSG'),
('Portero',	'Real Madrid'),
('Portero',	'Tottenham');

select * from equipación;

insert into EstilosQuímica (Nombre, Estadísticas) values 
('Ancla',	'Ritmo+Defensa+Físico'),
('Arquitecto',	'Pase+Físico'),
('Artista',	'Regate+Pase'),
('Catalizador',	'Ritmo+Pase'),
('Cazador',	'Ritmo+Tiro'),
('Centinela',	'Defensa+Físico'),
('Escudo',	'Reflejos+Estirada+Saque'),
('Espinazo',	'Defensa+Físico+Pase'),
('Felino',	'Reflejos+Velocidad+Posición'),
('Francotirador',	'Tiro+Regate'),
('Gladiador',	'Tiro+Defensa'),
('Guante',	'Salto+Estirada+Posición'),
('Guardián',	'Regate+Defensa'),
('Halcón',	'Ritmo+Tiro+Físico'),
('Maestro',	'Regate+Tiro+Pase'),
('Motor',	'Ritmo+Regate+Pase'),
('Ninguno',	'Ninguna'),
('Pared',	'Salto+Estirada+Saque'),
('Potente',	'Pase+Defensa'),
('Preciso',	'Regate+Tiro+Físico'),
('Rematador',	'Tiro+Físico'),
('Sombra',	'Ritmo+Defensa'),
('Tirador',	'Tiro+Pase');

select * from EstilosQuímica;

insert into Torneo (Nombre) values 
('Bundesliga'),
('Champions League'),
('Copa del Rey'),
('Coppa Italia'),
('Europa League'),
('FA Cup'),
('LaLiga'),
('Ligue 1'),
('Premier League'),
('Serie A');
select * from Torneo;

insert into Participación (Club_Nombre, Torneo_Nombre) values
('AC Milán',	'Coppa Italia'),
('AC Milán',	'Serie A'),
('Arsenal',	'Europa League'),
('Arsenal',	'FA Cup'),
('Arsenal',	'Premier League'),
('Atlético de Madrid',	'Champions League'),
('Atlético de Madrid',	'Copa del Rey'),
('Atlético de Madrid',	'LaLiga'),
('Barcelona',	'Champions League'),
('Barcelona',	'Copa del Rey'),
('Barcelona',	'LaLiga'),
('Bayern Munich',	'Bundesliga'),
('Bayern Munich',	'Champions League'),
('Borussia Dortmund',	'Bundesliga'),
('Borussia Dortmund',	'Champions League'),
('Chelsea',	'Champions League'),
('Chelsea',	'FA Cup'),
('Chelsea',	'Premier League'),
('Inter de Milán',	'Champions League'),
('Inter de Milán',	'Coppa Italia'),
('Inter de Milán',	'Serie A'),
('Juventus',	'Champions League'),
('Juventus',	'Coppa Italia'),
('Juventus',	'Serie A'),
('Liverpool',	'Champions League'),
('Liverpool',	'FA Cup'),
('Liverpool',	'Premier League'),
('Manchester City',	'Champions League'),
('Manchester City',	'FA Cup'),
('Manchester City',	'Premier League'),
('Manchester United',	'Champions League'),
('Manchester United',	'FA Cup'),
('Manchester United',	'Premier League'),
('Napoli',	'Coppa Italia'),
('Napoli',	'Europa League'),
('Napoli',	'Serie A'),
('PSG',	'Champions League'),
('PSG',	'Ligue 1'),
('Real Madrid',	'Champions League'),
('Real Madrid',	'Copa del Rey'),
('Real Madrid',	'LaLiga'),
('Tottenham',	'Europa League'),
('Tottenham',	'FA Cup'),
('Tottenham',	'Premier League');

select * from Participación;

insert into Balón (Fase, Torneo_Nombre) values
('Amarillo',	'LaLiga'),
('Blanco',	'LaLiga'),
('Eliminatorias',	'Champions League'),
('Final',	'Copa del Rey'),
('Grupos',	'Champions League'),
('Normal',	'Bundesliga'),
('Normal',	'Copa del Rey'),
('Normal',	'Europa League'),
('Normal',	'Ligue 1'),
('Normal',	'Premier League'),
('Normal',	'Serie A');
select * from Balón;

insert into Jugador (IdJugador,	Nombre,	Media,	Nacionalidad,	Posicion,	Edad,	Altura,	PiernaBuena,	Ritmo,	Regate,	Tiro,	Defensa,	Pase,	Fisico,	Skills,	PiernaMala,	Club_Nombre,	Entrenador_Nombre,	EstilosQuímica_Nombre) values
('BAY9',	'Lewandowski',	91,	'Polaca',	'DC',	32,	184,	'Der',	78,	86,	91,	43,	78,	82,	4,	4,	'Bayern Munich',	'Flick',	'Rematador'),
('FCB10',	'Messi',	93,	'Argentina',	'ED',	33,	170,	'Izq',	85,	95,	92,	38,	91,	65,	4,	4,	'Barcelona',	'Koeman',	'Francotirador'),
('JUV10',	'Dybala',	88,	'Argentina',	'SD',	26,	177,	'Izq',	85,	91,	85,	43,	84,	63,	4,	3,	'Juventus',	'Pirlo',	'Tirador'),
('JUV7',	'Cristiano Ronaldo',	92,	'Portuguesa',	'DC',	35,	187,	'Der',	89,	89,	93,	35,	81,	77,	5,	4,	'Juventus',	'Pirlo',	'Halcón'),
('LIV4',	'Van Dijk',	90,	'Holandesa',	'DFC',	29,	193,	'Der',	76,	72,	60,	91,	71,	86,	2,	3,	'Liverpool',	'Klopp',	'Centinela'),
('PSG10',	'Neymar',	91,	'Brasileña',	'EI',	28,	175,	'Der',	91,	94,	85,	36,	86,	59,	5,	5,	'PSG',	'Pochettino',	'Francotirador'),
('PSG7',	'Mbappe',	90,	'Francesa',	'DC',	21,	178,	'Der',	96,	91,	86,	39,	78,	76,	5,	4,	'PSG',	'Pochettino',	'Cazador'),
('RMA10',	'Luka Modric',	87,	'Croata',	'MC',	35,	172,	'Der',	73,	88,	76,	71,	89,	66,	4,	4,	'Real Madrid',	'Zidane',	'Maestro'),
('RMA12',	'Marcelo',	83,	'Brasileña',	'LTI',	32,	174,	'Izq',	79,	88,	73,	76,	80,	76,	5,	4,	'Real Madrid',	'Zidane',	'Guardián'),
('RMA4',	'Sergio Ramos',	89,	'Española',	'DFC',	34,	184,	'Der',	71,	74,	70,	88,	76,	85,	3,	3,	'Real Madrid',	'Zidane',	'Centinela'),
('RMA9',	'Benzema',	89,	'Francesa',	'DC',	32,	185,	'Der',	74,	87,	85,	40,	81,	76,	4,	4,	'Real Madrid',	'Zidane',	'Preciso');

select * from Jugador;

insert into HaceQuímica (Jugador_idJugador, Jugador_idJugador1, TipoLink) values
('BAY9',	'FCB10',	'Rojo'),
('BAY9',	'JUV10',	'Rojo'),
('BAY9',	'JUV7',	'Rojo'),
('BAY9',	'LIV4',	'Rojo'),
('BAY9',	'PSG10',	'Rojo'),
('BAY9',	'PSG7',	'Rojo'),
('BAY9',	'RMA10',	'Rojo'),
('BAY9',	'RMA12',	'Rojo'),
('BAY9',	'RMA4',	'Rojo'),
('BAY9',	'RMA9',	'Rojo'),
('FCB10',	'BAY9',	'Rojo'),
('FCB10',	'JUV10',	'Amarillo'),
('FCB10',	'JUV7',	'Rojo'),
('FCB10',	'LIV4',	'Rojo'),
('FCB10',	'PSG10',	'Rojo'),
('FCB10',	'PSG7',	'Rojo'),
('FCB10',	'RMA10',	'Amarillo'),
('FCB10',	'RMA12',	'Amarillo'),
('FCB10',	'RMA4',	'Amarillo'),
('FCB10',	'RMA9',	'Amarillo'),
('JUV10',	'BAY9',	'Rojo'),
('JUV10',	'FCB10',	'Amarillo'),
('JUV10',	'JUV7',	'Verde'),
('JUV10',	'LIV4',	'Rojo'),
('JUV10',	'PSG10',	'Rojo'),
('JUV10',	'PSG7',	'Rojo'),
('JUV10',	'RMA10',	'Rojo'),
('JUV10',	'RMA12',	'Rojo'),
('JUV10',	'RMA4',	'Rojo'),
('JUV10',	'RMA9',	'Rojo'),
('JUV7',	'BAY9',	'Rojo'),
('JUV7',	'FCB10',	'Rojo'),
('JUV7',	'JUV10',	'Verde'),
('JUV7',	'LIV4',	'Rojo'),
('JUV7',	'PSG10',	'Rojo'),
('JUV7',	'PSG7',	'Rojo'),
('JUV7',	'RMA10',	'Rojo'),
('JUV7',	'RMA12',	'Rojo'),
('JUV7',	'RMA4',	'Rojo'),
('JUV7',	'RMA9',	'Rojo'),
('PSG10',	'PSG7',	'Verde'),
('PSG10',	'RMA12',	'Amarillo'),
('PSG7',	'PSG10',	'Verde'),
('PSG7',	'RMA9',	'Amarillo'),
('RMA10',	'RMA12',	'Verde'),
('RMA10',	'RMA4',	'Verde'),
('RMA10',	'RMA9',	'Verde'),
('RMA12',	'RMA10',	'Verde'),
('RMA12',	'RMA4',	'Verde'),
('RMA12',	'RMA9',	'Verde'),
('RMA4',	'RMA10',	'Verde'),
('RMA4',	'RMA12',	'Verde'),
('RMA4',	'RMA9',	'Verde'),
('RMA9',	'RMA10',	'Verde'),
('RMA9',	'RMA12',	'Verde'),
('RMA9',	'RMA4',	'Verde');
select * from HaceQuímica;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
