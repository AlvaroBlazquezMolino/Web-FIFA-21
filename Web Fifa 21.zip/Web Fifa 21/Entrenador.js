$(function(){
  function req(acc, cb){ $.post('procesaENTRENADOR.php',{accion:acc,NomEnt:$('#NomEnt').val(),NomClubENT:$('#NomClubENT').val(),Nac:$('#Nac').val()},cb,'json').fail(()=>$('#respuesta3').html('<div class="alert alert-danger">Error al comunicarse con procesaENTRENADOR.php</div>')); }
  function esc(x){return $('<div>').text(x??'').html();}
  function render(r){if(!r.data||!r.data.length){$('#listaD3').html('<p>No hay entrenadores para mostrar.</p>');return;} let h='<table id="tablaD3" class="table table-striped table-hover"><thead><tr><th>Nombre</th><th>Club</th><th>Nacionalidad</th></tr></thead><tbody>'; r.data.forEach(d=>h+=`<tr><td>${esc(d.NomEnt)}</td><td>${esc(d.NomClubENT)}</td><td>${esc(d.Nac)}</td></tr>`); h+='</tbody></table>'; $('#listaD3').html(h); $('#tablaD3').DataTable(); $('#tablaD3 tbody').on('click','tr',function(){let c=$(this).children('td');$('#NomEnt').val(c.eq(0).text());$('#NomClubENT').val(c.eq(1).text());$('#Nac').val(c.eq(2).text());});}
  function msg(r){$('#respuesta3').html(`<div class="alert alert-${r.completado?'success':'danger'}">${r.message}</div>`);if(r.completado){$('#frmDeps3')[0].reset();load();}}
  function load(){req('ve',render)}
  function loadClubs(){$.post('procesaENTRENADOR.php',{accion:'clubes'},function(r){let s=$('#NomClubENT').empty();r.data.forEach(x=>s.append($('<option>',{value:x.Nombre,text:x.Nombre})));},'json');}
  $('#botonInserta3').click(()=>req('inserta',msg)); $('#botonModifica3').click(()=>req('modifica',msg)); $('#botonElimina3').click(()=>req('elimina',msg)); $('#botonVer3').click(load); loadClubs(); load();
});
