<?php
header("content-type:application/json");   

include "conexion.php";

$accion = 've';
$Capacidad = null;


if (count($_REQUEST) == 0) {
    $inputJSON = file_get_contents('php://input');
    $input = json_decode($inputJSON, TRUE);
    $_REQUEST = $input;
} 


if (isset($_REQUEST['accion'])) {
    $accion = $_REQUEST['accion'];
}

try {
    $conn = estableceConexion();
} catch (PDOException $e) {
    $msg = "No se pudo conectar a la base de datos: " .
            utf8_encode($e->getMessage());
    $resultado = array("data"=> [], "message"=> $msg, "completado" => false);
    echo json_encode($resultado);
    $conn = null;
    die();
}

try {
    if ($accion == "ve") {   
        $q = $conn->query('SELECT * from ESTADIO');  
        $resultado = array("data"=> $q->fetchAll(PDO::FETCH_ASSOC), "message"=> "Ok");
        echo json_encode($resultado);
    } else { 
        if (!isset($_REQUEST['NombreEst'])){
            $msg = "No ha proporcionado el ID, luego no puedo efectuar la acción " . $accion;
            
            $resultado = array("data"=> [], "message"=> $msg, "completado" => false);
            echo json_encode($resultado);
            $conn = null;
            die();
        }    
        $NombreEst = $_REQUEST['NombreEst'];

        if ($accion == "inserta" || $accion == "modifica") {
            if (!isset($_REQUEST['Capacidad'])) {
                $msg = "Faltan algunos datos por procorcionar, de modo que no podemos completar la acción " . $accion;
                
                $resultado = array("data"=> [], "message"=> $msg, "completado" => false);
                echo json_encode($resultado);
            } else {
                $Capacidad = $_REQUEST['Capacidad'];
            }
        }

        if ($accion == "inserta") {
            if (existeId($conn, $NombreEst)) {
                $msg = "El ID introducido ya se encuentra en la base de datos, por lo que no se puede insertar<br/>";
                
                $resultado = array("data"=> [], "message"=> $msg, "completado" => false);
                echo json_encode($resultado);
                $conn = null;
                die();
            }
            $sql = "INSERT INTO ESTADIO (Nombre, Capacidad) VALUES (:NombreEst, :Capacidad)";
        } else {
            if (!existeId($conn, $NombreEst)) {
                $msg = "El ID introducido no se encuentra en la base de datos, por lo que no se puede continuar";
                
                $resultado = array("data"=> [], "message"=> $msg, "completado" => false);
                echo json_encode($resultado);
                $conn = null;
                die();
            }

            if ($accion == "modifica") {
                $sql = "UPDATE ESTADIO SET Capacidad = :Capacidad WHERE Nombre = :NombreEst";
            } else if ($accion == "elimina") {
                $sql = "DELETE FROM ESTADIO WHERE Nombre = :NombreEst";
            }
        }
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':NombreEst', $NombreEst, PDO::PARAM_STR);

        if ($accion == "inserta" || $accion == "modifica") {
            $stmt->bindValue(':Capacidad', $Capacidad, PDO::PARAM_INT);
        }
        $success = $stmt->execute();

        switch ($accion) {
            case "inserta":
                $msg = "\nEl departamento " . $NombreEst . ", con id " . $Capacidad .
                        "' se ha insertado correctamente en la base de datos";
                break;
            case "modifica":
                $msg = "\nEl departamento con id " . $NombreEst . " se ha actualizado correctamente a las siglas '" . $Capacidad . "', nombre completo '" .  ".";  
                break;
            case "elimina":  
                $msg =  "\nEl departamento con id " . $NombreEst . " se ha eliminado correctamente. ";
        }

        $resultado = array("data"=> [], "message"=> $msg, "completado" => true);
        echo json_encode($resultado);
    }
} catch (PDOException $e) {
    $msg = "No se pudo completar la acción " . $accion .
    utf8_encode($e->getMessage());
    $resultado = array("data"=> [], "message"=> $msg, "completado" => false);
    echo json_encode($resultado);
} finally {    
    $conn = null;
    die();
}
