// Compatibilidad con la estructura original del proyecto.
// La sección ESTADIO de Web FIFA v3 ya contiene su lógica inline y usa procesaESTADIO.php.
