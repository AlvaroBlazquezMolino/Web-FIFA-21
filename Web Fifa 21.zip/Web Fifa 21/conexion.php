<?php

function estableceConexion () {
    $db = 'mysql:host=localhost;dbname=Fifa;charset=utf8';
    $user = 'root';
    $pass = '';
    
    $conn = new PDO($db, $user, $pass);
    $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $conn;
}


function existeId($conn, $id){
    $sql = "SELECT * FROM ESTADIO where Nombre = :NombreEst";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':NombreEst', $id, PDO::PARAM_STR);
    $stmt->execute();
    return ($stmt->rowCount()>0);
}