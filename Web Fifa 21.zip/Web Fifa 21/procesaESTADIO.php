<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'conexion.php';

function out($data = [], $message = 'Ok', $ok = true) {
    echo json_encode(['data'=>$data, 'message'=>$message, 'completado'=>$ok], JSON_UNESCAPED_UNICODE);
    exit;
}

$accion = $_REQUEST['accion'] ?? 've';
try {
    $conn = estableceConexion();
    if ($accion === 've') {
        $q = $conn->query('SELECT Nombre, Capacidad FROM Estadio ORDER BY Nombre');
        out($q->fetchAll(PDO::FETCH_ASSOC));
    }
    $nombre = trim($_REQUEST['NombreEst'] ?? '');
    if ($nombre === '') out([], 'Debe proporcionar el nombre del estadio.', false);

    if ($accion === 'inserta') {
        $cap = $_REQUEST['Capacidad'] ?? '';
        if ($cap === '') out([], 'Debe proporcionar la capacidad.', false);
        $stmt=$conn->prepare('INSERT INTO Estadio (Nombre, Capacidad) VALUES (:n,:c)');
        $stmt->execute([':n'=>$nombre, ':c'=>$cap]);
        out([], 'El estadio se ha insertado correctamente en la base de datos.');
    }
    if ($accion === 'modifica') {
        $cap = $_REQUEST['Capacidad'] ?? '';
        if ($cap === '') out([], 'Debe proporcionar la capacidad.', false);
        $stmt=$conn->prepare('UPDATE Estadio SET Capacidad=:c WHERE Nombre=:n');
        $stmt->execute([':n'=>$nombre, ':c'=>$cap]);
        if ($stmt->rowCount()===0) out([], 'No existe ese estadio o no hubo cambios.', false);
        out([], 'El estadio se ha modificado correctamente.');
    }
    if ($accion === 'elimina') {
        $stmt=$conn->prepare('DELETE FROM Estadio WHERE Nombre=:n');
        $stmt->execute([':n'=>$nombre]);
        if ($stmt->rowCount()===0) out([], 'No existe ese estadio.', false);
        out([], 'El estadio se ha eliminado correctamente.');
    }
    out([], 'Acción no reconocida.', false);
} catch (Throwable $e) {
    out([], 'No se pudo completar la acción: '.$e->getMessage(), false);
}
