<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'conexion.php';
function outC($data=[], $message='Ok', $ok=true){ echo json_encode(['data'=>$data,'message'=>$message,'completado'=>$ok],JSON_UNESCAPED_UNICODE); exit; }
$accion=$_REQUEST['accion']??'ve';
try{
 $db=estableceConexion();
 if($accion==='ve'){
  $q=$db->query('SELECT Nombre, `Federación_Nombre` AS Fed, Estadio_Nombre AS NomEst FROM Club ORDER BY Nombre');
  outC($q->fetchAll(PDO::FETCH_ASSOC));
 }
 if($accion==='federaciones'){
  $q=$db->query('SELECT Nombre FROM `Federación` ORDER BY Nombre'); outC($q->fetchAll(PDO::FETCH_ASSOC));
 }
 if($accion==='estadios'){
  $q=$db->query('SELECT Nombre FROM Estadio ORDER BY Nombre'); outC($q->fetchAll(PDO::FETCH_ASSOC));
 }
 $n=trim($_REQUEST['NomClub']??''); if($n==='') outC([], 'Debe proporcionar el nombre del club.', false);
 if($accion==='inserta'||$accion==='modifica'){
  $fed=trim($_REQUEST['Fed']??''); $est=trim($_REQUEST['NomEst']??'');
  if($fed===''||$est==='') outC([], 'Debe seleccionar una federación y un estadio.', false);
 }
 if($accion==='inserta'){
  $s=$db->prepare('INSERT INTO Club (Nombre, Estadio_Nombre, Federación_Nombre) VALUES (:n,:e,:f)');
  $s->execute([':n'=>$n,':e'=>$est,':f'=>$fed]); outC([], 'El club se ha insertado correctamente.');
 }
 if($accion==='modifica'){
  $s=$db->prepare('UPDATE Club SET Estadio_Nombre=:e, Federación_Nombre=:f WHERE Nombre=:n');
  $s->execute([':n'=>$n,':e'=>$est,':f'=>$fed]);
  if($s->rowCount()===0) outC([], 'No existe ese club o no hubo cambios.', false);
  outC([], 'El club se ha modificado correctamente.');
 }
 if($accion==='elimina'){
  $s=$db->prepare('DELETE FROM Club WHERE Nombre=:n'); $s->execute([':n'=>$n]);
  if($s->rowCount()===0) outC([], 'No existe ese club.', false); outC([], 'El club se ha eliminado correctamente.');
 }
 outC([], 'Acción no reconocida.', false);
}catch(Throwable $e){outC([], 'No se pudo completar la acción: '.$e->getMessage(), false);}
