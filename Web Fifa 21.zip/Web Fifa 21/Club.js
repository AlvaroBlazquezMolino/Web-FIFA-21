$(function(){
  function req(acc, cb){ $.post('procesaCLUB.php',{accion:acc,NomClub:$('#NomClub').val(),Fed:$('#Fed').val(),NomEst:$('#NomEst').val()},cb,'json').fail(function(x){ $('#respuesta2').html('<div class="alert alert-danger">Error al comunicarse con procesaCLUB.php</div>'); }); }
  function render(r){
    if(!r.data || !r.data.length){ $('#listaD2').html('<p>No hay clubes para mostrar.</p>'); return; }
    let h='<table id="tablaD2" class="table table-striped table-hover"><thead><tr><th>Nombre</th><th>Federación</th><th>Estadio</th></tr></thead><tbody>';
    r.data.forEach(d=>h+=`<tr><td>${esc(d.Nombre)}</td><td>${esc(d.Fed)}</td><td>${esc(d.NomEst)}</td></tr>`); h+='</tbody></table>'; $('#listaD2').html(h); $('#tablaD2').DataTable();
    $('#tablaD2 tbody').on('click','tr',function(){let c=$(this).children('td'); $('#NomClub').val(c.eq(0).text()); $('#Fed').val(c.eq(1).text()); $('#NomEst').val(c.eq(2).text());});
  }
  function esc(x){return $('<div>').text(x??'').html();}
  function msg(r){$('#respuesta2').html(`<div class="alert alert-${r.completado?'success':'danger'}">${r.message}</div>`); if(r.completado){$('#frmDeps2')[0].reset(); load();}}
  function load(){req('ve',render)}
  function loadFed(){ $.post('procesaCLUB.php',{accion:'federaciones'},function(r){let s=$('#Fed').empty(); r.data.forEach(x=>s.append($('<option>',{value:x.Nombre,text:x.Nombre})));},'json'); }
  function loadEst(){ $.post('procesaCLUB.php',{accion:'estadios'},function(r){$('#NomEst').attr('list','listaEstadios'); if(!$('#listaEstadios').length) $('body').append('<datalist id="listaEstadios"></datalist>'); $('#listaEstadios').empty(); r.data.forEach(x=>$('#listaEstadios').append($('<option>',{value:x.Nombre})));},'json'); }
  $('#botonInserta2').click(()=>req('inserta',msg)); $('#botonModifica2').click(()=>req('modifica',msg)); $('#botonElimina2').click(()=>req('elimina',msg)); $('#botonVer2').click(()=>load());
  loadFed(); loadEst(); load();
});
