<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'conexion.php';
function outE($data=[], $message='Ok', $ok=true){ echo json_encode(['data'=>$data,'message'=>$message,'completado'=>$ok],JSON_UNESCAPED_UNICODE); exit; }
$accion=$_REQUEST['accion']??'ve';
try{
 $db=estableceConexion();
 if($accion==='ve'){
  $q=$db->query('SELECT Nombre AS NomEnt, Club_Nombre AS NomClubENT, Nacionalidad AS Nac FROM Entrenador ORDER BY Nombre'); outE($q->fetchAll(PDO::FETCH_ASSOC));
 }
 if($accion==='clubes'){
  $q=$db->query('SELECT Nombre FROM Club ORDER BY Nombre'); outE($q->fetchAll(PDO::FETCH_ASSOC));
 }
 $n=trim($_REQUEST['NomEnt']??''); if($n==='') outE([], 'Debe proporcionar el nombre del entrenador.', false);
 if($accion==='inserta'||$accion==='modifica'){
  $club=trim($_REQUEST['NomClubENT']??''); $nac=trim($_REQUEST['Nac']??'');
  if($club===''||$nac==='') outE([], 'Debe proporcionar el club y la nacionalidad.', false);
 }
 if($accion==='inserta'){
  $s=$db->prepare('INSERT INTO Entrenador (Nombre, Nacionalidad, Club_Nombre) VALUES (:n,:na,:c)'); $s->execute([':n'=>$n,':na'=>$nac,':c'=>$club]); outE([], 'El entrenador se ha insertado correctamente.');
 }
 if($accion==='modifica'){
  $s=$db->prepare('UPDATE Entrenador SET Nacionalidad=:na, Club_Nombre=:c WHERE Nombre=:n'); $s->execute([':n'=>$n,':na'=>$nac,':c'=>$club]);
  if($s->rowCount()===0) outE([], 'No existe ese entrenador o no hubo cambios.', false); outE([], 'El entrenador se ha modificado correctamente.');
 }
 if($accion==='elimina'){
  $s=$db->prepare('DELETE FROM Entrenador WHERE Nombre=:n'); $s->execute([':n'=>$n]);
  if($s->rowCount()===0) outE([], 'No existe ese entrenador.', false); outE([], 'El entrenador se ha eliminado correctamente.');
 }
 outE([], 'Acción no reconocida.', false);
}catch(Throwable $e){outE([], 'No se pudo completar la acción: '.$e->getMessage(), false);}
